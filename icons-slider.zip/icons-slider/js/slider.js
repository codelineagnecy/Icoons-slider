// stable behaviour for slider
// smooth infinite auto-scroll leftwards
jQuery(document).ready(function($){
    var isElementorEditor = $('body').hasClass('elementor-editor-active') ||
        (window.elementorFrontend && elementorFrontend.isEditMode && elementorFrontend.isEditMode());

    function ensureTooltipsRoot(){
        var root = $('#icons-slider-tooltips-root');
        if(!root.length){
            root = $('<div id="icons-slider-tooltips-root"></div>').css({
                position: 'fixed',
                top: 0,
                left: 0,
                pointerEvents: 'none',
                zIndex: 9999
            }).appendTo('body');
        }
        return root;
    }

    function initContainer(container){
        var $container = $(container);
        if($container.data('iconsSliderInit')) return;
        $container.data('iconsSliderInit', true);

        // wrap slides in a direct child track when needed
        if(!$container.children('.icons-slider-track').length){
            $container.children('.icons-slide').wrapAll('<div class="icons-slider-track"></div>');
        }

        var $track = $container.children('.icons-slider-track');
        var $originalSlides = $track.children('.icons-slide').not('.is-clone');
        if(!$originalSlides.length) return;

        function getMinSlidesForAnimation(){
            return window.matchMedia('(max-width: 767px)').matches ? 3 : 5;
        }

        var $tooltipsRoot = ensureTooltipsRoot();

        // move original tooltips to body-root once and keep index mapping on slides
        $originalSlides.each(function(idx){
            var $slide = $(this);
            $slide.attr('data-tooltip-index', idx);
            var $tip = $slide.find('.slide-tooltip-wrapper').first();
            if($tip.length){
                $tip.detach().appendTo($tooltipsRoot);
            }
        });

        function getOriginalWidth(){
            var width = 0;
            $originalSlides.each(function(){
                width += $(this).outerWidth(true);
            });
            return width;
        }

        function cloneEnoughSlides(){
            $track.children('.icons-slide.is-clone').remove();
            var originalWidth = getOriginalWidth() || 1;
            var slideCount = $originalSlides.length;
            var minSlidesForAnimation = getMinSlidesForAnimation();

            // Clone only when we should animate for current viewport.
            var cloneFactor = slideCount >= minSlidesForAnimation ? 3 : 0;

            for(var i = 0; i < cloneFactor; i++){
                $originalSlides.each(function(){
                    $(this).clone().addClass('is-clone').attr('aria-hidden', 'true').appendTo($track);
                });
            }

            return originalWidth;
        }

        var originalWidth = getOriginalWidth();

        // in Elementor editor keep a clean centered preview: no clones, no animation
        if(isElementorEditor){
            $track.children('.icons-slide.is-clone').remove();
            $container.addClass('icons-slider-editor-mode');
            $track.css('transform', 'translateX(0)');
            return;
        }

        var slideCount = $originalSlides.length;
        var cloneFactor = slideCount >= getMinSlidesForAnimation() ? 3 : 0;
        cloneEnoughSlides();

        // Measure the actual rendered width of ONE set of slides from the DOM.
        // This includes flexbox gaps which outerWidth(true) misses.
        if (cloneFactor > 0) {
            originalWidth = $track[0].scrollWidth / (1 + cloneFactor);
        }

        var speed = 0.5;
        var pos = 0;
        // Animate threshold is viewport-aware: mobile 3+, desktop 5+.
        var running = slideCount >= getMinSlidesForAnimation();

        function updateModeClass(){
            var minSlidesForAnimation = getMinSlidesForAnimation();
            $container.toggleClass('icons-slider-static', slideCount < minSlidesForAnimation);
            $container.toggleClass('icons-slider-running', slideCount >= minSlidesForAnimation);
        }

        updateModeClass();

        // Time-based requestAnimationFrame loop at the same rate as the former
        // setInterval(step, 16) advancing `speed` px per tick (0.5 px / 16 ms =
        // 31.25 px/s). It only runs while the slider is animating, in view and
        // the tab is visible, so it does no work at all otherwise.
        var pxPerSecond = speed * 1000 / 16;
        var track = $track[0];
        var rafId = 0;
        var lastTs = null;
        var inView = true;
        var pageVisible = !document.hidden;

        function frame(ts){
            rafId = 0;
            if(lastTs !== null){
                // clamp so a long gap (e.g. a dropped frame burst) never jumps
                pos += pxPerSecond * Math.min(ts - lastTs, 100) / 1000;
                // Reset after one set for seamless infinite loop
                if(pos >= originalWidth){
                    pos -= originalWidth;
                }
                track.style.transform = 'translateX(' + (-pos) + 'px)';
            }
            lastTs = ts;
            sync();
        }

        function sync(){
            if(running && inView && pageVisible){
                if(!rafId) rafId = requestAnimationFrame(frame);
            } else {
                if(rafId){
                    cancelAnimationFrame(rafId);
                    rafId = 0;
                }
                lastTs = null;
            }
        }

        if(typeof window.IntersectionObserver === 'function'){
            new IntersectionObserver(function(entries){
                inView = entries[entries.length - 1].isIntersecting;
                sync();
            }).observe(container);
        }

        document.addEventListener('visibilitychange', function(){
            pageVisible = !document.hidden;
            sync();
        });

        sync();

        function pause(){
            running = false;
            sync();
        }

        function resume(){
            running = slideCount >= getMinSlidesForAnimation();
            sync();
        }

        $container.on('mouseenter.iconsSlider', pause);
        $container.on('mouseleave.iconsSlider', resume);

        // passive touch listeners: pause while touched, never block page scrolling;
        // touchcancel also resumes because the browser may cancel the touch when it takes over a scroll
        container.addEventListener('touchstart', pause, { passive: true });
        container.addEventListener('touchend', function(e){
            if(e.touches && e.touches.length) return;
            resume();
        }, { passive: true });
        container.addEventListener('touchcancel', resume, { passive: true });

        $(window).on('resize.iconsSlider', function(){
            slideCount = $originalSlides.length;
            cloneFactor = slideCount >= getMinSlidesForAnimation() ? 3 : 0;
            cloneEnoughSlides();
            if (cloneFactor > 0) {
                originalWidth = $track[0].scrollWidth / (1 + cloneFactor);
            } else {
                originalWidth = getOriginalWidth();
            }
            // update running state based on slide count
            running = slideCount >= getMinSlidesForAnimation();
            updateModeClass();
            sync();
            if(pos >= originalWidth){
                pos = pos % originalWidth;
            }
        });
    }

    $('.icons-slider-container').each(function(){
        initContainer(this);
    });

    // on slide hover, position tooltip and show
    $(document)
        .off('mouseenter.iconsSliderTooltip mouseleave.iconsSliderTooltip', '.icons-slider-container .icons-slide')
        .on('mouseenter.iconsSliderTooltip', '.icons-slider-container .icons-slide', function(){
            var $slide = $(this);
            var idx = parseInt($slide.attr('data-tooltip-index'), 10);
            if(isNaN(idx)) return;

            var $tooltip = $('#icons-slider-tooltips-root .slide-tooltip-wrapper').eq(idx);
            if(!$tooltip.length) return;

            var slideOffset = $slide.offset();
            $tooltip.css({
                left: (slideOffset.left + $slide.outerWidth() / 2) + 'px',
                top: (slideOffset.top - $tooltip.outerHeight() - 12) + 'px',
                transform: 'translateX(-50%)',
                display: 'block',
                pointerEvents: 'none'
            });
        })
        .on('mouseleave.iconsSliderTooltip', '.icons-slider-container .icons-slide', function(){
            var idx = parseInt($(this).attr('data-tooltip-index'), 10);
            if(isNaN(idx)) return;
            var $tooltip = $('#icons-slider-tooltips-root .slide-tooltip-wrapper').eq(idx);
            if($tooltip.length) $tooltip.css('display', 'none');
        });
});
